document.querySelectorAll('.lesson').forEach(item => {
    item.addEventListener('click', function () {
        let content = this.nextElementSibling;
        let isOpen = this.dataset.open === "true"; // Проверяем текущее состояние
        
        if (isOpen) {
            content.style.display = "none";
            this.innerHTML = `${this.innerHTML.slice(2)}`;
            this.dataset.open = "false";
        } else {
            content.style.display = "block";
            this.innerHTML = `${this.innerHTML.slice(2)}`;
            this.dataset.open = "true";
        }
    });
});

// Получаем элементы
const modal = document.getElementById("modal");
const modal1 = document.getElementById("modal1");
const loginBtn = document.querySelector(".btn-login"); // Используем класс btn-login
const regBtn = document.querySelector(".btn-register")
const closeBtn = document.querySelector(".close-btn");
const body = document.querySelector("body");
const overlay = document.getElementById('overlay');

// Открытие модального окна
loginBtn.addEventListener("click", () => {
  modal.style.display = "flex"; // Показать модальное окно
  modal.style.flexDirection = "column"; // Добавляем flex-column
  overlay.style.display = "block"; // Показать затемнение
});

regBtn.addEventListener("click", () => {
  modal1.style.display = "flex"; // Показать модальное окно
  modal1.style.flexDirection = "column"; // Добавляем flex-column
  overlay.style.display = "block"; // Показать затемнение
});

// Закрытие модального окна при нажатии на кнопку закрытия
closeBtn.addEventListener("click", () => {
  modal.style.display = "none"; // Скрыть модальное окно
  overlay.style.display = "none";
});

closeBtn.addEventListener("click", () => {
  modal1.style.display = "none"; // Скрыть модальное окно
  overlay.style.display = "none";
});

// Закрытие модального окна при клике на затемненный фон
window.addEventListener("click", (event) => {
  if (event.target === overlay) {
    modal.style.display = "none"; // Скрыть модальное окно
    overlay.style.display = "none";
  }
});

window.addEventListener("click", (event) => {
  if (event.target === overlay) {
    modal1.style.display = "none"; // Скрыть модальное окно
    overlay.style.display = "none";
  }
});



  const toggleBtn = document.querySelector('.dropdown-title');
  const menu = document.querySelector('.dropdown-menu');

  toggleBtn.addEventListener('click', () => {
    if (menu.style.display === 'none' || menu.style.display === '') {
      menu.style.display = 'block';
    } else {
      menu.style.display = 'none';
    }
  });



  const all = document.querySelector('.btn-all');
  const article = document.querySelector('.btn-article')
  const video = document.querySelector('.btn-video')
  const podcasts = document.querySelector('.btn-podcasts')


  const buttons = [all, article, video, podcasts]


    buttons.forEach(btn => {
      btn.addEventListener('click', () =>{
        buttons.forEach(b => {
          b.style.border ='none'
          b.querySelector('.btn-text').style.color = '#9A9CA5';
        });
        btn.style.border = '1px solid #FF3F3A';
        btn.querySelector('.btn-text').style.color = '#FF3F3A';
      });
    });


const button1 = document.querySelector('.btn-1')
const button2 = document.querySelector('.btn-2')
const button3 = document.querySelector('.btn-3')
const button4 = document.querySelector('.btn-4')

const buttonsblog = [button1, button2, button3, button4]

buttonsblog.forEach( btn => {
  btn.addEventListener('click', () => {
    buttonsblog.forEach(b => {
      b.style.color = '#424551';
    });
    btn.style.color = '#ff3f3a';
  });
});